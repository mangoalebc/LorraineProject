<link rel="stylesheet" href="style/deco.css" type="text/css">
<?php require "db/connect.php";?>
<?php
	if(isset($_POST['senlogin'])){
	//print "<font color='red'>ready when you are!</font>";
		if(!empty($_POST['username']) and !empty($_POST['password']) ){
		$username=$_POST['username'];
		$password=$_POST['password'];
		$sqlreuset="SELECT * FROM login WHERE username ='$username' AND password='$password'";
		$processRequest=$db->prepare($sqlreuset);
		$processRequest->execute();
			foreach($processRequest as $MYDATA){
				$userMail= $MYDATA['email'];$MyID=$MYDATA['username'];
			}	
				if($userMail != null){
					$err= "login was a success!";
					print "<script>window.location='main.php?MyID=$MyID'</script>";
				}else{
					$err= "<center><font color='red'>Sorry wrong username/password!</font></center>";
				}
		}else{
			$err=  "<center>Form is empty!</center>";
		}
	}
	//cancel login and redirect to home page
	if(isset($_POST['sendback'])){
	print "<font color='red'>cccccc</font>";
		print "<script>window.location='index.php'</script>";
	
	}


?>
<div id="line_header">OUR EVENTS - FUND RAISING - SKILLS AND TRAINING - MENTORSHIP - SITE VISIT - OUR TEAMS
<label style="float:right;padding-right:5px;">DROP US A COMMENT | CONTACT US</label>
</div>
<div id="wrapper"><!--wrapper-->
	<div id="pre_deader"><img src="logo.jpg" width="60px" height="30px" style="opacity:0.6;float:left;"/>
		<div id="pre_deader_text"><label style="font-size:18px;color:#fff;font-family:script;float:left;">MYNLCS|</label>
		<div id="pre_deader_text2"><label style="font-size:10px;color:#000;font-family:;">Working Towards </br></label>
		<label style="font-size:10px;color:#000;font-family:script;padding-left:0px;">Excellency</label></div>
		</div>
		<div id="pre_deader_links">
			<label style="font-size:18px;color:#000;font-family:arial;padding-left:0px;float:right;">Galleries | news</label>
		</div>
	</div>
	
	<div id="header">

	</div>
<div id="left">
		MY LOGGINS COMES HERE!
		<fieldset id="loginf_set">
			<form name="long-user" action="loginS.php" method="post">
			<table id="loginf_set_table"><th colspan="3">ADMIN SIGN-IN PORTAL</th>
			<tr><td>Username</td><td>	<input type="text" name="username" value="" placeholder="" class="textlog" />	</td></tr>
			<tr><td>Password</td><td>	<input type="password" name="password" value="" placeholder="" class="textlog" />	</td></tr>		
			<tr><td colspan="3"><center><input type="submit" name="senlogin" value="SIGN IN"   class="buttlog" />
			<input type="submit" name="sendback" value="CANCEL"  class="buttlog" /></center></td></tr>
			</table>
			</form>		
		<//?php print $err;?>
		</fieldset>
</div>

<div id="footer">

</div>

		</div><!--wrapper-->
<!--<label style="font-size:12px;color:#000;font-family:script;">Mamelodi Youth Netball League Communication System</label>
		-->