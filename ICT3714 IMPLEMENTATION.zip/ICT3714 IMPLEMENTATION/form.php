<?php
 require "db/connect.php";$myID=$_GET['MyID'];
?>
<link rel="stylesheet" href="style/deco.css" type="text/css">
<div id="line_header">
<?php
if($_POST['register_coordinator']){
		if(!empty($_POST['co-name']) AND !empty($_POST['email']) AND !empty($_POST['title']) AND !empty($_POST['team'])){
		//
		$co_name=$_POST['co-name'];	$email=$_POST['email'];$team=$_POST['team'];$Facilitator=$_POST['title'];
		$username=$co_name;$password= substr($co_name,0,4). "".date('y').substr($email,6,5);
		$sqlreuset="insert into coordinators (coordinatorName,email,teamName,Facilitator,username,password)
		VALUES('$co_name','$email','$team','$Facilitator','$username','$password')";
		$processRequest=$db->prepare($sqlreuset);
		$processRequest->execute();
		$err="<img src='loading/ajax_loader.gif'>";
		//*************************
			// Total processes
	$total = 10;print "<center>...Registering New User <img src='loading/ajax_loader.gif'></center>";
	// Loop through process
	for($i=9; $i<=$total; $i++){
		// Calculate the percentation
		$percent = intval($i/$total * 100)."%";    
	// This is for the buffer achieve the minimum size in order to flush data
		echo str_repeat(' ',1024*64);
	// Send output to browser immediately
		flush();
	// Sleep one second so we can see the delay
		sleep(1);
	}
	print "<script>window.location='form.php'</script>";
		//*************************
		}else{
			$err=  "Please fill the form to register the Manager";
		}
	
	}
?>
<label style="float:right;padding-right:5px;">Logged in as: Username | Log out</label>
</div>
<div id="wrapper"><!--wrapper-->
	<div id="pre_deader"><img src="logo.jpg" width="60px" height="30px" style="opacity:0.6;float:left;border-radius:70px;"/>
		<div id="pre_deader_text"><label style="font-size:18px;color:#fff;font-family:script;float:left;">MYNLCS|</label>
		<div id="pre_deader_text2"><label style="font-size:10px;color:#000;font-family:;">Working Towards </br></label>
		<label style="font-size:10px;color:#000;font-family:script;padding-left:0px;">Excellency</label></div>
		</div>
		<div id="pre_deader_links">
			<label style="font-size:18px;color:#000;font-family:arial;padding-left:0px;float:right;">New Schedules | <a href='main.php'>My Menu</a></label>
		</div>
	</div>
	
	<div id="header">
	<label style='font-size:20px;color:orange;'>League Coordinator Panel|</label><a href='fixture.php'>VIEW FIXTURE </a>- <a href='fixture.php'>CREATE FIXTURE </a>- <a href='monitor.php'>MONITOR ACCOUNT</a>
	</div>
<div id="main_center">
		<div id='before_devider_form'><div id='before_devider'>MY MANAGED USERS!</div>Registered CO-Ordinators
		<form name="register_coordinator" method="post" action="form.php">
		<table id='reg_co'>
		<tr style='border-bottom:solid thin red;'><th>Co-Name</th><th>Position</th><th>Team Name</th><th>Password</th><th>ID</th></tr>	
		<?php
		$sqlreuset="SELECT * FROM coordinators";
		$processRequest=$db->prepare($sqlreuset);
		$processRequest->execute();
			foreach($processRequest as $MYDATA){
				$userMail= $MYDATA['email'];$coorname =$MYDATA['coordinatorName'];$Facilitator=$MYDATA['Facilitator'];
				$TeamName=$MYDATA['teamName'];$Password=$MYDATA['password'];$CO_ID=$MYDATA['coordinatorID'];
				print "<tr><td>$coorname</td><td>$Facilitator</td><td>$TeamName</td><td>$Password</td><td style='border-right:solid thin red;'>$CO_ID</td></tr>";
			}?>
				
		</table>
		</form>			
		</div>
		<center><div id='devider'></div></center>
		<div id='after_devider_form'><div id='after_devider'>NEW USER DATA</div>Register CO-Ordinator</br>
		<form name="register_coordinator" method="post" action="form.php">
		<table id="tab_co">
		<tr><td>Coordinator </td><td><input type="text" name="co-name" placeholder="Co-ordinator Name"/></td></tr>
		<tr><td>Email Address</td><td><input type="email" name="email" placeholder="Email"/></td></tr>
		<tr><td>Title </td><td><input type="text" name="title" placeholder="Tilte"/></td></tr>
		<tr><td>Team </td><td><input type="text" name="team" placeholder="Team"/></td></tr>			
			<tr><td colspan="3">
			<input type="submit" name="register_coordinator" value="REGISTER" placeholder="Team" id="subm"/>			
			</td></tr>
		</table>
		</form>	<?php print $err; ?>	
		</div>
</div>

<div id="footer">

</div>

		</div><!--wrapper-->
<!--<label style="font-size:12px;color:#000;font-family:script;">Mamelodi Youth Netball League Communication System</label>
		-->