<?php
 require "db/connect.php";$myID=$_GET['MyID'];
?>
<link rel="stylesheet" href="style/deco.css" type="text/css">
<div id="line_header">

<label style="float:right;padding-right:5px;">Logged in as: <?php print $myID;?>| Log out</label>
</div>
<div id="wrapper"><!--wrapper-->
	<div id="pre_deader"><img src="logo.jpg" width="60px" height="30px" style="opacity:0.6;float:left;border-radius:70px;"/>
		<div id="pre_deader_text"><label style="font-size:18px;color:#fff;font-family:script;float:left;">MYNLCS|</label>
		<div id="pre_deader_text2"><label style="font-size:10px;color:#000;font-family:;">Working Towards </br></label>
		<label style="font-size:10px;color:#000;font-family:script;padding-left:0px;">Excellency</label></div>
		</div>
		<div id="pre_deader_links">
			<label style="font-size:18px;color:#000;font-family:arial;padding-left:0px;float:right;">New Schedules | <a href='main.php'>My Menu</a></label>
		</div>
	</div>
	
	<div id="header">
	<label style='font-size:20px;color:orange;'>League Coordinator Panel|</label><a href='fixture.php'>VIEW FIXTURE </a>- <a href='fixture.php'>CREATE FIXTURE </a>- <a href='monitor.php'>MONITOR ACCOUNT</a>-<a href='view_Log.php'>LOG STANDING </a>
	</div>
<div id="main_center">
		<div id='before_devider_form'><div id='before_devider'>DELETE MANAGED USERS!</div>
		<form name="register_coordinator" method="post" action="monitor.php">
		<table id='reg_co'>
		<tr style='border-bottom:solid thin red;'><th>Co-Name</th><th>Manager Position</th><th>Team Name</th><th>Password</th><th>ID</th><th>FACT</th><th>Update</th></tr>	
		<?php
		$sqlreuset="SELECT * FROM coordinators";
		$processRequest=$db->prepare($sqlreuset);
		$processRequest->execute();
			foreach($processRequest as $MYDATA){$delete=$MYDATA['coordinatorID'];$update=$MYDATA['coordinatorID'];
				$userMail= $MYDATA['email'];$coorname =$MYDATA['coordinatorName'];$Facilitator=$MYDATA['Facilitator'];
				$TeamName=$MYDATA['teamName'];$Password=$MYDATA['password'];$CO_ID=$MYDATA['coordinatorID'];
				print "<tr><td>$coorname</td><td><a href='form.php?co_ID=$delete&tlhogo'>$Facilitator</a></td><td>$TeamName</td><td>$Password</td><td>$CO_ID</td>
				<td><a href='monitor.php?delete=$delete&factor=rex&manager=$coorname'>DELETE</a></td>
				<td><a href='monitor.php?update=$update&change=update'>CHANGE</a></td></tr>";
			}?>
				
		</table>
		</form>			
		</div>
		<center><div id='devider'></div></center>
		<div id='after_devider_form'><div id='after_devider'>DATA PROCESSING UTILITY</div></br></br><?php $updateID=$_GET['update'];?>
		<form name="register_coordinator" method="post" action="<?php print "monitor.php?managerid=$updateID"; ?>">
		<table id="tab_co">
		
			<tr><td colspan="3">
			<!--<input type="submit" name="" value="" placeholder="Team"/>-->
			<?php
if($_GET['factor']=="rex"){
		if(!empty($_GET['delete'])){
		//
		$delete=$_GET['delete'];$coorname=$_GET['manager'];
		$sqlreuset="DELETE FROM coordinators WHERE coordinatorID='$delete'";
		$processRequest=$db->prepare($sqlreuset);
		$processRequest->execute();
		$err="<center><img src='loading/loadingbar.gif'></center>";
		//*************************
		print "Erasing Data For User Identified as: $coorname";
			// Total processes
	$total = 10;print "<center><img src='loading/loadingbar.gif'></br></br></br></br>... Please wait...</center>";
	// Loop through process
	for($i=9; $i<=$total; $i++){
		// Calculate the percentation
		$percent = intval($i/$total * 100)."%";    
	// This is for the buffer achieve the minimum size in order to flush data
		echo str_repeat(' ',1024*64);
	// Send output to browser immediately
		flush();
	// Sleep one second so we can see the delay
		sleep(1);
	}
	print "<script>alert('User Successfully Deleted')</script>";
	print "<script>window.location='monitor.php'</script>";
		//*************************
		}else{
			$err=  "Please fill the form to register the Coordinator";
		}	
	}
?>
<!--FOR UPDATING THE FORM DATA FOR MANAGERS-->
<?php
	if(isset($_GET['update'])){$updateID=$_GET['update'];
		$userData="SELECT * FROM coordinators WHERE coordinatorID='$updateID'";
		$manager=$db->prepare($userData);
		$manager->execute();
foreach($manager as $manager_info){		
		//print "UP GRADED"; ?>
		<form name="update_coordinator" method="post" action="monitor.php?managerid=$updateID">
		<table id="tab_co">Updating Information For " <?php print strtoupper($manager_info['coordinatorName']);?> "
		<tr><td>Coordinator </td><td><input type="text" name="coname" value='<?php print $manager_info['coordinatorName'];?>'/></td></tr>
		<tr><td>Email Address</td><td><input type="email" name="email" value='<?php print $manager_info['email'];?>'/></td></tr>
		<tr><td>Title </td><td><input type="text" name="title" value='<?php print $manager_info['Facilitator'];?>'/></td></tr>
		<tr><td>Team </td><td><input type="text" name="team" value='<?php print $manager_info['teamName'];?>'/></td></tr>
		<tr><td>.</td></tr>	<tr><td>.</td></tr>	
			<tr><td colspan="3">
			<input type="submit" name="update_coordinator" value="REGISTER" id="subm"/>
			<!--<input type="submit" name="" value="" placeholder="Team"/>-->
			
			</td></tr>
		</table>
		</form>
<?php	
		}//f_each
	}	
?>
			</td></tr>
		</table>
		</form>	<?php print $err; ?>	
		
	<?php

	if(isset($_POST['update_coordinator'])){
	global $db;
	$updateID=$_GET['managerid'];
	$co_name=$_POST['coname'];$email=$_POST['email'];$co_title=$_POST['title'];$co_team=$_POST['team'];
	$co_team=$_POST['team']; $mangerfac=$_POST['Facilitator'];
		//print "user updated nicely";
	$UpdateManager="update coordinators
		set coordinatorName='$co_name',email='$email',teamName='$co_team',Facilitator='$co_title'
		WHERE coordinatorID='$updateID'
		";
		$RELuTS=$db->prepare($UpdateManager);
		$RELuTS->execute();
		$err="<center><img src='loading/loadingbar.gif'></center>";
		//*************************
			// Total processes
	$total = 10;print "<center><img src='loading/loadingbar.gif' width='300px' height='80px'></br></br>...Making changes to $co_name`s Information</center>";
	// Loop through process
	for($i=9; $i<=$total; $i++){
		// Calculate the percentation
		$percent = intval($i/$total * 100)."%";    
	// This is for the buffer achieve the minimum size in order to flush data
		echo str_repeat(' ',1024*64);
	// Send output to browser immediately
		flush();
	// Sleep one second so we can see the delay
		sleep(1);
	}
	//print "<script>alert('Data Successfully Updated')</script>";
	print "<script>window.location='monitor.php'</script>";
	}
	
?>



		</div>
</div>

<div id="footer">

</div>

		</div><!--wrapper-->
<!--<label style="font-size:12px;color:#000;font-family:script;">Mamelodi Youth Netball League Communication System</label>
		-->