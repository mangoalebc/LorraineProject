/*--This JavaScript method for Print command--*/
    function PrintDoc() {
        var toPrint = document.getElementById('printSection');
        var popupWin = window.open('', '_blank', 'width=750,height=650,location=no,left=200px');
        popupWin.document.open();
        popupWin.document.write('<html><title>Payment Receit </title></head><body onload="window.print()"><center><h2> Customer payment Slip</h2></center>')
        popupWin.document.write(toPrint.innerHTML);
        popupWin.document.write('</html>');
        popupWin.document.close();
    }
/*--This JavaScript method for Print Preview command--*/
    function PrintPreview() {
        var toPrint = document.getElementById('printSection');
        var popupWin = window.open('', '_blank', 'width=750,height=650,location=no,left=200px');
        popupWin.document.open();
        popupWin.document.write('<html><title>Payment Receit Print Preview::</title></head><body"><center><h2> Preview Customer Details Slip</h2></center>')
        popupWin.document.write(toPrint.innerHTML);
        popupWin.document.write('</html>');
        popupWin.document.close();
    }