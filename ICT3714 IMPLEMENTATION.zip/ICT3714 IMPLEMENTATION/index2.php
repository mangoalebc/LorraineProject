<link href="design.css" rel="stylesheet" type="text/css">
<div id="head">

</div>
	<div id="body">
		<a href="login.php"><div id="admin"><center>ADMIN</center></div></a>
		<div id="co_admins"><center>CO-ADMIN</center></div>
	</div>
<div id="footer">



</div>