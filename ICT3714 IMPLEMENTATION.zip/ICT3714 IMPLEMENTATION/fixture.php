<?php
 require "db/connect.php";$myID=$_GET['MyID'];
?>
<link rel="stylesheet" href="style/deco.css" type="text/css">
<div id="line_header">
<?php
if($_POST['create_fixture']){
		if(!empty($_POST['match_type']) AND !empty($_POST['location']) AND !empty($_POST['teamName']) AND !empty($_POST['date_match']) AND !empty($_POST['teamName2'])){
		$MatchType=$_POST['match_type'];$field_location=$_POST['location'];$oppontent=$_POST['teamName'];$oppontent2=$_POST['teamName2'];
		$DateOfMatch=$_POST['date_match'];$match_TIME =$_POST['Time_match'];
		//create-fixture
		$sqlreuset="insert into teams (match_type,location,teamName,date,teamManagerID,homeTeam,Time)
		VALUES('$MatchType','$field_location','$oppontent','$DateOfMatch','non yet','$oppontent2','$match_TIME')";
		$processRequest=$db->prepare($sqlreuset);
		$processRequest->execute();
		$err="<img src='loading/ajax_loader.gif'>";
		//*************************
			// Total processes
	$total = 10;print "<center>...Creating Match Fixture <img src='loading/ajax_loader.gif'></center>";
	// Loop through process
	for($i=9; $i<=$total; $i++){
		// Calculate the percentation
		$percent = intval($i/$total * 100)."%";   
	// This is for the buffer achieve the minimum size in order to flush data
		echo str_repeat(' ',1024*64);
	// Send output to browser immediately
		flush();
	// Sleep one second so we can see the delay
		sleep(1);
	}
	print "<script>window.location='fixture.php'</script>";
		//*************************
		}else{
			$err=  "Please fill the form to register the Manager";
		}	
	}
?>
<label style="float:right;padding-right:5px;">Logged in as: Username | Log out</label>
</div>
<div id="wrapper"><!--wrapper-->
	<div id="pre_deader"><img src="logo.jpg" width="60px" height="30px" style="opacity:0.6;float:left;border-radius:70px;"/>
		<div id="pre_deader_text"><label style="font-size:18px;color:#fff;font-family:script;float:left;">MYNLCS|</label>
		<div id="pre_deader_text2"><label style="font-size:10px;color:#000;font-family:;">Working Towards </br></label>
		<label style="font-size:10px;color:#000;font-family:script;padding-left:0px;">Excellency</label></div>
		</div>
		<div id="pre_deader_links">
			<label style="font-size:18px;color:#000;font-family:arial;padding-left:0px;float:right;">New Schedules | <a href='main.php'>My Menu</a></label>
		</div>
	</div>
	
	<div id="header">
	<label style='font-size:20px;color:orange;'>League Coordinator Panel|</label><a href='view_fixture.php'>VIEW FIXTURE </a>- <a href='fixture.php'>CREATE FIXTURE </a>- <a href='monitor.php'>MONITOR ACCOUNT</a>-<a href='view_Log.php'>LOG STANDING </a>
	</div>
<div id="main_center">
		<div id='before_devider_form'><div id='before_devider'>FIXTURE DATA!</div>Current Fixture Line-Up
		<form name="register_coordinator" method="post" action="fixture.php">
		<table id='reg_co' style='width:475px;'>
		<tr style='border-bottom:solid thin red;'><th>Opponent</th><th>Field-Name</th><th>Match Date</th><th>Time</th></tr>	
		<?php
		$sqlreuset="SELECT * FROM teams";
		$processRequest=$db->prepare($sqlreuset);
		$processRequest->execute();
			foreach($processRequest as $MYDATA){
				$TeamName= $MYDATA['teamName'];$location =$MYDATA['location'];$Facilitator=$MYDATA['teamManagerID'];
				$date=$MYDATA['date'];$Match_type=$MYDATA['match_type'];$time=$MYDATA['Time'];$Opponent=$MYDATA['homeTeam'];$TeamID=$MYDATA['teamID'];
				print "<tr><td><a href='fixture.php?update=fixtureupdate&fixtureID=$TeamID'> $TeamName <font color='yellow'>v</font> $Opponent </a></td><td>$location</td><td>$date</td><td style='border-right:solid thin red;'>$time</td></tr>";
			}?>
				
		</table>
		</form>			
		</div>			
		<?php
			if(isset($_GET['update'])=='fixtureupdate'){
						$TeamID=$_GET['fixtureID'];
		$sqlreuset="SELECT * FROM teams Where teamID=$TeamID";
				$processRequest=$db->prepare($sqlreuset);
			$processRequest->execute();
			foreach($processRequest as $MYDATA){
				$TeamName= $MYDATA['teamName'];$location =$MYDATA['location'];$Facilitator=$MYDATA['teamManagerID'];
				$date=$MYDATA['date'];$Match_type=$MYDATA['match_type'];$time=$MYDATA['Time'];$Opponent=$MYDATA['homeTeam'];$TeamID=$MYDATA['teamID'];
		print "<center><div id='devider'></div></center>
		<div id='after_devider_form'><div id='after_devider'>FIXTURE DATA</div>Update Fixture Line-Up</br>
		<form name='Update_fixture' method='post' action='fixture.php?update=fixtureupdate&fixtureID=$TeamID'>
		<table id='tab_co'>
		<tr><td>Type Of Match </td><td><input type='text' name='match_type' placeholder='Type of Match' value=' $Match_type'/></td></tr>
		<tr><td>Field</td><td><input type='text' name='location' placeholder='Match location' value='$location'/></td></tr>
		<tr><td>Team 1 </td><td><input type='text' name='teamName' placeholder='Team Name 1' value='$TeamName'/></td></tr>
		<tr><td>Team 2 </td><td><input type='text' name='teamName2' placeholder='Team Name 2' value='$Opponent'/></td></tr>
		<tr><td>Time</td><td><input type='text' name='Time_match' placeholder='Time' value='$time'/></td></tr>
		<tr><td>Match Date</td><td><input type='date' name='date_match' placeholder='Date' style='width:173px' value='$date'/></td></tr>
		
			<tr><td colspan='3'>
			<input type='submit' name='Update_fixture' value='UPDATE ' placeholder='Team' id='subm' />						
			</td></tr>
		</table>
		</form>	 $err
		</div>";
			}//close foreach
			}else{
			//show this form first
			//}
		
		?>
		<center><div id='devider'></div></center>
		<div id='after_devider_form'><div id='after_devider'>FIXTURE DATA</div>Update Fixture Line-Up</br>
		<form name='create_fixture' method='post' action='fixture.php'>
		<table id='tab_co'>
		<tr><td>Type Of Match </td><td>
		<select name='match_type' value=''>
			<option>Netball Premier Leaque</option>
			<option>Brutal Fruit Netball Cup</option>
			<option>Spar Netball Championships</option>
			<option>Motsepe Championship Cup</option>
			<option>Diamond League</option>
		</select>				
		<!--<input type='text' name='match_type' placeholder='Type of Match' value='<?php //print $Match_type ;?>'/></td></tr>-->
		<tr><td>Field</td><td><input type='text' name='location' placeholder='Match location' value='<?php //print $location ;?>'/></td></tr>
		<tr><td>Team 1 </td><td><input type='text' name='teamName' placeholder='Team Name 1' value='<?php //print $TeamName  ;?>'/></td></tr>
		<tr><td>Team 2 </td><td><input type='text' name='teamName2' placeholder='Team Name 2' value='<?php //print $Opponent ;?>'/></td></tr>
		<tr><td>Time</td><td><input type='text' name='Time_match' placeholder='Time' value='<?php //print $time ;?>'/></td></tr>
		<tr><td>Match Date</td><td><input type='date' name='date_match' placeholder='Date' style='width:173px' value='<?php // print $date;?>'/></td></tr>
		
			<tr><td colspan='3'>
			<input type='submit' name='create_fixture' value='REGISTER' placeholder='Team' id='subm' />			
			</td></tr>
		</table>
		</form>	<?php print $err; ?>	
		</div>
	<?php	}		
		?>
</div>

<div id="footer">

</div>

		</div><!--wrapper-->
<!--<label style="font-size:12px;color:#000;font-family:script;">Mamelodi Youth Netball League Communication System</label>
		-->