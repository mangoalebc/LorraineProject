<?php

	try{
		$username="root";$password="";$server="localhost";$cont="mysql:host=$server;dbname=Lolah";
		$db= new PDO($cont,$username,$password);//print "connected";
	}catch(PDOException $K){
		die("Could not connect to". $K->getMessage());
	}

?>