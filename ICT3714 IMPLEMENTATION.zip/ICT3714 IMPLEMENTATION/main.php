<?php
 require "db/connect.php";$myID=$_GET['MyID'];
?>
<link rel="stylesheet" href="style/deco.css" type="text/css">
<div id="line_header">
<label style="float:right;padding-right:5px;">Logged in as: <?php print strtolower($myID);?> | <a href='logout.php'>Log out</a></label>
</div>
<div id="wrapper"><!--wrapper-->
	<div id="pre_deader"><img src="logo.jpg" width="60px" height="30px" style="opacity:0.6;float:left;"/>
		<div id="pre_deader_text"><label style="font-size:18px;color:#fff;font-family:script;float:left;">MYNLCS|</label>
		<div id="pre_deader_text2"><label style="font-size:10px;color:#000;font-family:;">Working Towards </br></label>
		<label style="font-size:10px;color:#000;font-family:script;padding-left:0px;">Excellency</label></div>
		</div>
		<div id="pre_deader_links">
			<label style="font-size:18px;color:#000;font-family:arial;padding-left:0px;float:right;"><a href='form.php'>New Schedules </a>| My Menu</label>
		</div>
	</div>
	
	<div id="header">
	<label style='font-size:20px;color:orange;'>League Coordinator Panel|</label><a href='view_fixture.php'>VIEW FIXTURE </a>- <a href='fixture.php'>CREATE FIXTURE </a>- <a href='monitor.php'>MONITOR ACCOUNT</a>
	<a href='view_Log.php'>LOG STANDING </a>
	</div>
<div id="left">
		UP COMING EVENTS!
		<table id='reg_co'>
		<tr style='border-bottom:solid thin red;'><th>Away Team</th><th> </th><th>Home Team</th><th>Match Date</th><th>Time</th></tr>	
		<?php
		$sqlreuset="SELECT * FROM teams";
		$processRequest=$db->prepare($sqlreuset);
		$processRequest->execute();
			foreach($processRequest as $MYDATA){
				$TeamName= $MYDATA['teamName'];$location =$MYDATA['location'];$Team2=$MYDATA['homeTeam'];
				$date=$MYDATA['date'];$Match_type=$MYDATA['match_type'];$Match_time=$MYDATA['Time'];
				print "<tr><td>$TeamName</td><td style='color:#fff;'> VS </td><td>$Team2</td><td>$date</td><td style='border-right:solid thin red;'>$Match_time</td></tr>";
			}?>
				
		</table>
</div>

<div id="footer">
<marquee><?php print "<tr><td>$TeamName</td><td style='color:#fff;'> VS </td><td>$Team2</td><td>$date</td><td>$Match_time</td></tr>";?></marquee>
</div>

		</div><!--wrapper-->
<!--<label style="font-size:12px;color:#000;font-family:script;">Mamelodi Youth Netball League Communication System</label>
		-->