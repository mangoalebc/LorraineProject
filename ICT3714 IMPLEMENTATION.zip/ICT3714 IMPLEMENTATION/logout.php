<?php
session_start();
session_destroy();
	unset($_SESSION['username']);
print "<script>window.location='logins.php'</script>";
?>